%% replace NA with 10000 before reading them into matlab.
pm_25 = csvread('\\ais-fs1.sfu.ca\home\Redirected_Profiles\psang\Desktop\code_to_Jiguo\pm25_2000.csv',1, 0);
ntrain = 80;
ntest = 21;
ID = pm_25(1:101,1);
train = pm_25(~logical(ID), 3:368);
test = pm_25(logical(ID), 3:368);
train_cell=cell(1,ntrain);
train_t_cell=cell(1,ntrain);
nm = (1:366);
for i=1:ntrain
a = train(i, 1:366);
b = a > 500;  % NA positions
train_t_cell{i} = nm(~logical(b));                 
train_cell{i} = a(~logical(b));
end
%%



%% create test data
test_cell=cell(1,ntest);
test_t_cell=cell(1,ntest);
nm = (1:366);
for i=1:ntest
a = test(i, 1:366);
b = a > 500;  % NA positions
test_t_cell{i} = nm(~logical(b));                 
test_cell{i} = a(~logical(b));
end
%%


%% PACE for training data
addpath('\\ais-fs1.sfu.ca\home\Redirected_Profiles\psang\Desktop\code_to_Jiguo\PACE_release2.11\release2.11\PACE');
param_X = setOptions('regular',0,'FVE', 0.9999); 
trainRes = FPCA(train_cell, train_t_cell, param_X);
save('train.mat', 'trainRes')
%%


%% PACE prediction
[testhat, testPCscore, testPC_var] = FPCApred(trainRes,test_cell,test_t_cell);
save('test.mat','testPCscore')
%%

