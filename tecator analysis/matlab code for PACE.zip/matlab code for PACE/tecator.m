%% (1) Data preprocessing.
clear;
%%cd('C:\Users\hzhu\Documents\MATLAB\WorkingGroup1\tecator');
%%cd('Desktop/code_to_Jiguo')

%% addpath('C:\Users\hzhu\Documents\MATLAB\Matlabfunctions');
%% tecator = dlmread('C:\Users\hzhu\Documents\MATLAB\WorkingGroup1\tecator\tecator.txt','', 150, 0);
addpath('/Users/psang/Downloads/bgamv120');
tecator = dlmread('~/Desktop/code_to_Jiguo/tecator.txt','', 150, 0);


%%tec=mat2vec(tecator');
b = tecator';
tec = b(1:end);
all_samples=NaN(240,125);
for i=1:240
    all_samples(i,:)=tec((i-1)*125+1:i*125);    
end

%%

nm=(851:2:1050)';
ntrain=187;
ntest=53;

%%
A = randsample(size(all_samples,1),ntrain);
    list=zeros(size(all_samples,1),1);
    list(A)=1;
    train_spec=all_samples(logical(list),1:100);
    test_spec=all_samples(~logical(list),1:100); 
    train_res=all_samples(logical(list),125); 
    test_res=all_samples(~logical(list),125);
    numgrid=size(train_spec, 2);
    train_cell=mat2cell(train_spec,ones(1,ntrain),numgrid)';
    t_cell=mat2cell(repmat(nm',ntrain,1),ones(1,ntrain),numgrid)';
 %%  
    
    
    
   %% (2) Now apply the method.     
        
    addpath('~/Desktop/code_to_Jiguo/PACE_release2.11/release2.11/PACE');
    param_X = setOptions('regular',2,'selection_k',20,'corrPlot',0,'rho',-1,'ngrid',55); 
    trainRes= FPCA(train_cell, t_cell, param_X);   %perform PCA on x
   
    numBasis= getVal(trainRes,'no_opt');
    trainPCscore = getVal(trainRes,'xi_est'); 
    %Phihat=getVal(trainRes,'phi');
    %hatsig2_x=getVal(trainRes,'sigma');
    lamhat=getVal(trainRes,'lambda');
    test_cell=mat2cell(test_spec,ones(1,ntest),numgrid)';
   
    [testhat, testPCscore, testPC_var]=FPCApred(trainRes,test_cell,t_cell,2);
    trainPC_scaled=normcdf(trainPCscore,zeros(ntrain,numBasis),repmat(sqrt(lamhat),ntrain,1));
    testPC_scaled=normcdf(testPCscore,zeros(ntest,numBasis),repmat(sqrt(lamhat),ntest,1));
    trainPC = horzcat(trainPC_scaled, train_res); 
    testPC = horzcat(testPC_scaled, test_res); 
    
    dlmwrite('traintec.csv', trainPC,'delimiter', ',');
    dlmwrite('testtec.csv', testPC, 'delimiter', ',');
    